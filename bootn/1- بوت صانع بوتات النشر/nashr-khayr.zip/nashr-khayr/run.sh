nohup python3 -B bot.py &
echo $! > save_pid.txt