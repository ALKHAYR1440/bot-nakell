["5205501394:AAHdhKbDl9w_EN2W5l3muY6EBylg0nuGcMo","5113640822:AAFgcVp7FHHcTe-8zOacCRtVtfNum7DU8W8"]
token : 5126148314:AAGjkUlAnbjoA_Sw7QGoJ8agKNg6feuId9w
dev  : 2143599302


* add multiple bots together